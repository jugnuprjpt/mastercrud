"use client";
import React, { useEffect, useState } from "react";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import * as Yup from "yup";

function TableData() {
  const [listData, setListData] = useState([]);
  const [show, setShow] = useState(false);
  const [showEdit, setShowEdit] = useState(false);

  const notify = () => toast.success("Detail Added Sucessfully");

  const FormValidation = () => {
    
    return Yup.object().shape({
        firstName: Yup.string()
        ?.trim()
        .required("Enter your name")
        .test(
          "len",
          "Min 2 characters required",
          (val) => val && val.toString().length >= 2
        ),
        designation: Yup.string()
        ?.trim()
        .required("Enter your designation")
        .test(
          "len",
          "Min 2 characters required",
          (val) => val && val.toString().length >= 2
        ),

   

      email: Yup.string()
        ?.trim()
        .email("Please Enter Valid Email")
        .required("Enter Your Email"),

        gender: Yup.string().required('Please select a gender'),

      
    });
  };

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(FormValidation()),
    mode: "onChange",
  });

  const submitHandler = (data) => {
    setListData((prev)=>[...prev,data])
    notify()
    setShow(false)
  };

  useEffect(() => {
    listingData();
  }, []);

  const listingData = async () => {
    const res = await fetch("http://18.206.145.130:8080/api/v1/employees");
    const data = await res.json();
    const getData = data.employees;
    setListData(getData);
  };

  const handleDelete=(getId)=>{
    const deleteData = listData.filter((item)=>getId !== item )
    setListData(deleteData)
    toast.success("deleted sucessfully")     
  }
  return (
    <>
      <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
        <nav className="bg-blue-500  border-gray-200 dark:bg-gray-900">
          <div className="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
            <a
              // href="https://flowbite.com/"
              className="flex items-center space-x-3 rtl:space-x-reverse"
            >
              <img
                src="https://flowbite.com/docs/images/logo.svg"
                className="h-8"
                alt="Flowbite Logo"
              />
              <span className="self-center text-2xl font-semibold whitespace-nowrap text-white">
                Employees
              </span>
            </a>
            <div className="flex md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse">
              <button
                type="button"
                onClick={() => setShow(true)}
                className="text-white bg-white  focus:ring-4 focus:outline-none font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 md:flex"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6 text-black"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 9v6m3-3H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                  />
                </svg>
                <span className="ps-3 text-black">Add New Employee</span>
              </button>
              <button
                data-collapse-toggle="navbar-cta"
                type="button"
                className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
                aria-controls="navbar-cta"
                aria-expanded="false"
              >
                <span className="sr-only">Open main menu</span>
                <svg
                  className="w-5 h-5"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 17 14"
                >
                  <path
                    stroke="currentColor"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M1 1h15M1 7h15M1 13h15"
                  />
                </svg>
              </button>
            </div>
            <div
              className="items-center justify-between hidden w-full md:flex md:w-auto md:order-1"
              id="navbar-cta"
            >
              <ul className="flex flex-col font-medium p-4 md:p-0 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                <li>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 rtl:inset-r-0 rtl:right-0 flex items-center ps-3 pointer-events-none">
                      <svg
                        className="w-5 h-5 text-gray-500 dark:text-gray-400"
                        aria-hidden="true"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fill-rule="evenodd"
                          d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                          clip-rule="evenodd"
                        ></path>
                      </svg>
                    </div>
                    <input
                      type="text"
                      id="table-search"
                      className="block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      placeholder="Search for items"
                    ></input>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </nav>

        <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
              <th scope="col" className="p-4"></th>
              <th scope="col" className="px-6 py-3">
                Name
              </th>
              <th scope="col" className="px-6 py-3">
                Email
              </th>
              <th scope="col" className="px-6 py-3">
                Designation
              </th>
              <th scope="col" className="px-6 py-3">
                Gender
              </th>
              <th scope="col" className="px-6 py-3">
                Action
              </th>
            </tr>
          </thead>
          {listData.map((item) => (
            <>
              <tbody>
                <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                  <td className="w-4 p-4">
                    <div className="flex items-center cursor-pointer">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.5}
                        stroke="currentColor"
                        className="w-6 h-6 "
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M12 9v6m3-3H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                        />
                      </svg>
                    </div>
                  </td>
                  <td
                    scope="row"
                    className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                  >
                    {item?.firstName}
                  </td>
                  <td className="px-6 py-4">{item.email}</td>
                  <td className="px-6 py-4">{item.designation}</td>
                  <td className="px-6 py-4">{item.gender}</td>
                  <td className="px-6 py-4">
                    <a
                      href="#"
                      className="font-medium text-blue-600 dark:text-blue-500 hover:underline"
                    >
                      <div className="flex md:space-x-2 ">
                        <span onClick={()=>setShowEdit(true)}>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          strokeWidth={1.5}
                          stroke="currentColor"
                          className="w-6 h-6"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L6.832 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125"
                          />
                        </svg>
                        </span>
                    <span onClick={()=>handleDelete(item)}>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          strokeWidth={1.5}
                          stroke="currentColor"
                          className="w-6 h-6"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                          />
                        </svg>
                        </span>
                      </div>
                    </a>
                  </td>
                </tr>
              </tbody>
            </>
          ))}
        </table>

        {show && (
          <>
            <div
              id="crud-modal"
              aria-hidden="true"
              className="fixed top-0 left-20 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full mt-40"
            >
              <div className="relative p-4 w-full max-w-md max-h-full mx-auto">
                <div className="relative bg-stone-400 rounded-lg shadow dark:bg-gray-700">
                  <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Create Detail
                    </h3>
                    <button
                      onClick={() => setShow(false)}
                      className="text-black-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                      data-modal-toggle="crud-modal"
                    >
                      <svg
                        className="w-3 h-3"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 14 14"
                      >
                        <path
                          stroke="currentColor"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                        />
                      </svg>
                      <span className="sr-only">Close modal</span>
                    </button>
                  </div>

                  <form
                    onSubmit={handleSubmit(submitHandler)}
                    className="p-4 md:p-5"
                  >
                    <div className="grid gap-4 mb-4 grid-cols-2">
                      <Controller
                        defaultValue={""}
                        control={control}
                        name="firstName"
                        render={({ field }) => (
                          <div className="col-span-2">
                            <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                              Name
                            </label>
                            <input
                              type="text"
                              id="name"
                              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                              placeholder="Type your name"
                              {...field}
                            />

                            {errors?.name && (
                              <span className="text-red-500 text-sm ">
                                {" "}
                                {errors?.name?.message}
                              </span>
                            )}
                          </div>
                        )}
                      />
                      <Controller
                        defaultValue={""}
                        control={control}
                        name="email"
                        render={({ field }) => (
                          <div className="col-span-2">
                            <label
                              htmlFor="email"
                              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                              Email
                            </label>
                            <input
                              type="email"
                              id="email"
                              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                              placeholder="Type your email"
                              {...field}
                            />
                            {errors?.email && (
                              <span className="text-red-500 text-sm ">
                                {" "}
                                {errors?.email?.message}
                              </span>
                            )}
                          </div>
                        )}
                      />
                      <Controller
                        defaultValue={""}
                        control={control}
                        name="designation"
                        render={({ field }) => (
                          <div className="col-span-2">
                            <label
                              htmlFor="designation"
                              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                              Designation
                            </label>
                            <input
                              type="text"
                              id="designation"
                              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                              placeholder="Type your designation"
                              {...field}
                            />

                            {errors?.designation && (
                              <span className="text-red-500 text-sm ">
                                {" "}
                                {errors?.designation?.message}
                              </span>
                            )}
                          </div>
                        )}
                      />
                      <div className="col-span-2">
                        <label
                          htmlFor="name"
                          className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >
                          Gender
                        </label>
                        <Controller
            name="gender"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <>
                <input
                  {...field}
                  type="radio"
                  id="male"
                  value="male"
                  checked={field.value === "male"}
                />
                &nbsp;
                <label htmlFor="male">Male</label>
                &nbsp;
                <input
                  {...field}
                  type="radio"
                  id="female"
                  value="female"
                  checked={field.value === "female"}
                />
                &nbsp;
                <label htmlFor="female">Female</label>

                {errors?.gender && (
                              <span className="text-red-500 text-sm ">
                                {" "}
                                {errors?.gender?.message}
                              </span>
                            )}
              </>
            )}
          />
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="text-white inline-flex items-center bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                    >
                      Submit
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </>
        )}

{showEdit && (
          <>
            <div
              id="crud-modal"
              aria-hidden="true"
              className="fixed top-0 left-20 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full mt-40"
            >
              <div className="relative p-4 w-full max-w-md max-h-full mx-auto">
                <div className="relative bg-stone-400 rounded-lg shadow dark:bg-gray-700">
                  <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Edit Detail
                    </h3>
                    <button
                      onClick={() => setShowEdit(false)}
                      className="text-black-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                      data-modal-toggle="crud-modal"
                    >
                      <svg
                        className="w-3 h-3"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 14 14"
                      >
                        <path
                          stroke="currentColor"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                        />
                      </svg>
                      <span className="sr-only">Close modal</span>
                    </button>
                  </div>

                  <form
                    onSubmit={handleSubmit(submitHandler)}
                    className="p-4 md:p-5"
                  >
                    <div className="grid gap-4 mb-4 grid-cols-2">
                      <Controller
                        defaultValue={listData.firstName}
                        control={control}
                        name="firstName"
                        render={({ field }) => (
                          <div className="col-span-2">
                            <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                              Name
                            </label>
                            <input
                              type="text"
                              id="name"
                              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                              placeholder="Type your name"
                              {...field}
                            />

                            {errors?.name && (
                              <span className="text-red-500 text-sm ">
                                {" "}
                                {errors?.name?.message}
                              </span>
                            )}
                          </div>
                        )}
                      />
                      <Controller
                        defaultValue={""}
                        control={control}
                        name="email"
                        render={({ field }) => (
                          <div className="col-span-2">
                            <label
                              htmlFor="email"
                              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                              Email
                            </label>
                            <input
                              type="email"
                              id="email"
                              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                              placeholder="Type your email"
                              {...field}
                            />
                            {errors?.email && (
                              <span className="text-red-500 text-sm ">
                                {" "}
                                {errors?.email?.message}
                              </span>
                            )}
                          </div>
                        )}
                      />
                      <Controller
                        defaultValue={""}
                        control={control}
                        name="designation"
                        render={({ field }) => (
                          <div className="col-span-2">
                            <label
                              htmlFor="designation"
                              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                              Designation
                            </label>
                            <input
                              type="text"
                              id="designation"
                              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                              placeholder="Type your designation"
                              {...field}
                            />

                            {errors?.designation && (
                              <span className="text-red-500 text-sm ">
                                {" "}
                                {errors?.designation?.message}
                              </span>
                            )}
                          </div>
                        )}
                      />
                      <div className="col-span-2">
                        <label
                          htmlFor="name"
                          className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >
                          Gender
                        </label>
                        <Controller
            name="gender"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <>
                <input
                  {...field}
                  type="radio"
                  id="male"
                  value="male"
                  checked={field.value === "male"}
                />
                &nbsp; 
                <label htmlFor="male">Male</label>
                &nbsp; 
                <input
                  {...field}
                  type="radio"
                  id="female"
                  value="female"
                  checked={field.value === "female"}
                />
                 &nbsp; 
                <label htmlFor="female">Female</label>

                {errors?.gender && (
                              <span className="text-red-500 text-sm ">
                                {" "}
                                {errors?.gender?.message}
                              </span>
                            )}
              </>
            )}
          />
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="text-white inline-flex items-center bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                    >
                      Submit
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </>
        )}
      </div>


      <ToastContainer
position="top-right"
autoClose={2000}
hideProgressBar={false}
newestOnTop={false}
closeOnClick
rtl={false}
pauseOnFocusLoss
draggable
pauseOnHover
theme="light"
/>
    </>
  );
}

export default TableData;
