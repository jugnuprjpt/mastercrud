
import * as Yup from "yup";
export const FormValidation = () => {
  const phoneRegExp =
    /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
  return Yup.object().shape({
    name: Yup.string()
      ?.trim()
      .required("Enter your companyName name")
      .test(
        "len",
        "Min 2 characters required",
        (val) => val && val.toString().length >= 2
      ),
      personName: Yup.string()
      ?.trim()
      .required("Enter your personName name")
      .test(
        "len",
        "Min 2 characters required",
        (val) => val && val.toString().length >= 2
      ),

      contact: Yup.string()
      .required("Enter mobile number")
      .matches(phoneRegExp, "Mobile number can be 10 digits only")
      .min(10, "Min 10 characters required")
      .max(10, "Max 10 characters required"),
      
      alternativeContact: Yup.string()
      .required("Enter alternative Contact number")
      .matches(phoneRegExp, "Mobile number can be 10 digits only")
      .min(10, "Min 10 characters required")
      .max(10, "Max 10 characters required"),

      email: Yup.string()
      ?.trim()
      .email("Please Enter Valid Email")
      .required("Enter Your Email"),

      alternativeEmail: Yup.string()
      ?.trim()
      .email("Please Enter Valid Email")
      .required("Enter Your alternative Email"),

  });
};